
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import os

BOT_TOKEN = os.environ.get("BOT_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🤖 AshishTradeBot is live! Use /strategy, /midday, /eod, /alerts, /addalert, /removealert.")

async def strategy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("📈 Today's Strategy: Watch BEL above ₹405, SL ₹397, Target ₹425. Market range-bound with selective stock momentum.")

async def midday(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🕛 Midday Update: Market stable. PSU banks showing strength. Watch Cochin Shipyard and GRSE for volume spike.")

async def eod(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("📊 EOD Summary: BEL +2.3%, Axis Bank flat, Nifty closed mildly higher. Sector rotation in Defence & Infra.")

async def alerts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔔 Active Alerts:\n1. BEL > ₹405\n2. GRSE Volume > 500K\n3. AxisBank > ₹980")

async def addalert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("✅ Alert added (demo). Dynamic alert system coming soon.")

async def removealert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("❌ Alert removed (demo). Full alert engine launching in next update.")

app = ApplicationBuilder().token(BOT_TOKEN).build()

app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("strategy", strategy))
app.add_handler(CommandHandler("midday", midday))
app.add_handler(CommandHandler("eod", eod))
app.add_handler(CommandHandler("alerts", alerts))
app.add_handler(CommandHandler("addalert", addalert))
app.add_handler(CommandHandler("removealert", removealert))

if __name__ == "__main__":
    print("🚀 AshishTradeBot backend running...")
    app.run_polling()
